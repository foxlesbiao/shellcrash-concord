#!/bin/sh
# Copyright (C) Juewuy

[ -n "$__IS_MODULE_7_GATEWAY_LOADED" ] && return
__IS_MODULE_7_GATEWAY_LOADED=1

. "$GT_CFG_PATH"
. "$CRASHDIR"/menus/check_port.sh
. "$CRASHDIR"/libs/gen_base64.sh
load_lang 7_gateway

# 访问与控制主菜单
gateway() {
    while true; do
        comp_box "\033[30;47m$GW_TITLE\033[0m"
        content_line "1) $GW_MENU_FW_WAN			\033[32m$fw_wan\033[0m"
        content_line "2) $GW_MENU_TG_BOT		\033[32m$bot_tg_service\033[0m"
        content_line "3) $GW_MENU_DDNS"
        [ "$disoverride" != "1" ] && {
            content_line "4) $GW_MENU_WG\t\033[32m$wg_service\033[0m"
        }
        btm_box "" \
            "0) $COMMON_BACK"
        read -r -p "$COMMON_INPUT> " num
        case "$num" in
        "" | 0)
            break
            ;;
        1)
            if [ -n "$(pidof CrashCore)" ] && [ "$firewall_mod" = 'iptables' ]; then
                comp_box "\033[33m$GW_FW_STOP_WARN\033[0m" \
                    "$GW_CONFIRM_CONTINUE"
                btm_box "1) $GW_YES" \
                    "0) $GW_NO_BACK"
                read -r -p "$COMMON_INPUT> " res
                if [ "$res" = 1 ]; then
                    "$CRASHDIR"/start.sh stop && set_fw_wan
                else
                    continue
                fi
            else
                set_fw_wan
            fi
            ;;
        2)
            set_bot_tg
            ;;
        3)
            . "$CRASHDIR"/menus/ddns.sh && ddns_menu
            ;;
        4)
            set_wireguard
            ;;
        esac
    done
}

# 公网防火墙
set_fw_wan() {
    while true; do
        [ -z "$fw_wan" ] && fw_wan=ON
        line_break
        separator_line "="
        content_line "\033[31m$GW_WARN\033[0m$GW_FW_VPS_HINT"
        [ -n "$fw_wan_ports" ] &&
            content_line "$GW_FW_MANUAL_PORTS\033[36m$fw_wan_ports\033[0m"
        [ -n "$vms_port$sss_port" ] &&
            content_line "$GW_FW_AUTO_PORTS\033[36m$vms_port $sss_port\033[0m"
        content_line "$GW_FW_DEFAULT_BLOCK\033[33m$mix_port,$db_port\033[0m"
        separator_line "="
        btm_box "1) $GW_FW_TOGGLE\033[36m$fw_wan\033[0m" \
            "2) $GW_FW_ADD_PORT" \
            "3) $GW_FW_REMOVE_PORT" \
            "4) $GW_FW_CLEAR_PORTS" \
            "" \
            "0) $COMMON_BACK"
        read -r -p "$COMMON_INPUT> " num
        case $num in
        "" | 0)
            break
            ;;
        1)
            if [ "$fw_wan" = ON ]; then
                comp_box "$GW_FW_DISABLE_CONFIRM" \
                    "$GW_FW_DISABLE_RISK"
                btm_box "1) $GW_YES" \
                    "0) $GW_NO_BACK"
                read -r -p "$COMMON_INPUT> " res
                if [ "$res" = 1 ]; then
                    fw_wan=OFF
                else
                    fw_wan=ON
                fi
            else
                fw_wan=ON
            fi
            setconfig fw_wan "$fw_wan"
            ;;
        2)
            port_count=$(echo "$fw_wan_ports" | awk -F',' '{print NF}')
            if [ "$port_count" -ge 10 ]; then
                msg_alert "\033[31m$GW_FW_PORT_LIMIT\033[0m"
            else
                line_break
                read -r -p "$GW_INPUT_ALLOW_PORT> " port
                if echo ",$fw_wan_ports," | grep -q ",$port,"; then
                    msg_alert "\033[31m$GW_ERR_DUP_PORT\033[0m"
                elif [ "$port" -lt 1 ] || [ "$port" -gt 65535 ]; then
                    msg_alert "\033[31m$GW_ERR_PORT_RANGE\033[0m"
                else
                    fw_wan_ports=$(echo "$fw_wan_ports,$port" | sed "s/^,//")
                    if setconfig fw_wan_ports "$fw_wan_ports"; then
                        common_success
                    else
                        common_faileds
                    fi
                fi
            fi
            ;;
        3)
            while true; do
                comp_box "\033[36m$GW_INPUT_REMOVE_PORT\033[0m" \
                    "$GW_INPUT_0_BACK"
                read -r -p "$GW_INPUT_PLAIN> " port
                if [ "$port" = 0 ]; then
                    break
                elif echo ",$fw_wan_ports," | grep -q ",$port,"; then
                    if [ "$port" -lt 1 ] || [ "$port" -gt 65535 ]; then
                        msg_alert "\033[31m$GW_ERR_INPUT\033[0m" \
                            "\033[31m$GW_ERR_PORT_RANGE\033[0m"
                    else
                        fw_wan_ports=$(echo ",$fw_wan_ports," | sed "s/,$port//; s/^,//; s/,$//")
                        setconfig fw_wan_ports "$fw_wan_ports"
                        break
                    fi
                else
                    msg_alert "\033[31m$GW_ERR_INPUT\033[0m" \
                        "\033[31m$GW_ERR_PORT_NOT_FOUND\033[0m"
                fi
            done
            ;;
        4)
            fw_wan_ports=''
            setconfig fw_wan_ports
            msg_alert "\033[32m$GW_OK\033[0m"
            ;;
        *)
            errornum
            ;;
        esac
    done
}

# tg_BOT相关
set_bot_tg_config() {
    setconfig TG_TOKEN "$TOKEN" "$GT_CFG_PATH"
    setconfig TG_CHATID "$chat_ID" "$GT_CFG_PATH"
    # 设置机器人快捷命令
    JSON=$(
        cat <<EOF
{
  "commands": [
    {"command": "$my_alias", "description": "$GW_TG_CMD_MENU"},
    {"command": "help",  "description": "$GW_TG_CMD_HELP"}
  ]
}
EOF
    )
    TEXT="$GW_TG_DONE_PREFIX /$my_alias $GW_TG_DONE_SUFFIX"
    . "$CRASHDIR"/libs/web_json.sh
    bot_api="https://api.telegram.org/bot$TOKEN"
    web_json_post "$bot_api/setMyCommands" "$JSON"
    web_json_post "$bot_api/sendMessage" '{"chat_id":"'"$chat_ID"'","text":"'"$TEXT"'","parse_mode":"Markdown"}'

    comp_box "\033[32m$TEXT\033[0m"
}

set_bot_tg_init() {
    . "$CRASHDIR"/menus/bot_tg_bind.sh && private_bot && set_bot
    if [ "$?" = 0 ]; then
        set_bot_tg_config
        return 0
    else
        return 1
    fi
}

set_bot_tg_service() {
    if [ "$bot_tg_service" = ON ]; then
        bot_tg_service=OFF
        . "$CRASHDIR"/menus/bot_tg_service.sh && bot_tg_stop
    else
        bot_tg_service=ON
        [ -n "$(pidof CrashCore)" ] && . "$CRASHDIR"/menus/bot_tg_service.sh &&
            bot_tg_start && bot_tg_cron
    fi
    setconfig bot_tg_service "$bot_tg_service"
}

set_bot_tg() {
    while true; do
        [ -n "$ts_auth_key" ] && ts_auth_key_info="$GW_SET"
        [ -n "$TG_CHATID" ] && TG_CHATID_info="$GW_BOUND"
        comp_box "\033[31m$GW_WARN\033[0m$GW_TG_WARN"
        btm_box "1) $GW_TG_TOGGLE	\033[32m$bot_tg_service\033[0m" \
            "2) $GW_TG_BIND	\033[32m$TG_CHATID_info\033[0m" \
            "3) $GW_TG_MENUPUSH	\033[32m$TG_menupush\033[0m" \
            "" \
            "0) $COMMON_BACK"
        read -r -p "$COMMON_INPUT> " num
        case "$num" in
        "" | 0)
            break
            ;;
        1)
            . "$GT_CFG_PATH"
            if [ -n "$TG_CHATID" ]; then
                set_bot_tg_service
            else
                msg_alert "\033[31m$GW_TG_BIND_FIRST\033[0m"
            fi
            ;;
        2)
            if [ -n "$chat_ID" ] && [ -n "$push_TG" ] && [ "$push_TG" != 'publictoken' ]; then
                comp_box "$GW_TG_BOUND_DETECTED" \
                    "$GW_TG_USE_DIRECT"
                btm_box "1) $GW_YES" \
                    "0) $GW_NO"
                read -r -p "$COMMON_INPUT> " res
                if [ "$res" = 1 ]; then
                    TOKEN="$push_TG"
                    set_bot_tg_config
                    continue
                fi
            fi
            set_bot_tg_init
            ;;
        3)
            if [ "$TG_menupush" = ON ]; then
                TG_menupush=OFF
            else
                TG_menupush=ON
            fi
            setconfig TG_menupush "$TG_menupush" "$GT_CFG_PATH"
            set_bot_tg
            ;;
        *)
            errornum
            ;;
        esac
    done
}
set_wireguard() {
    while true; do

        if [ -n "$wg_public_key" ]; then
            wgp_key_info='*********'
        else
            unset wgp_key_info
        fi

        if [ -n "$wg_private_key" ]; then
            wgv_key_info='*********'
        else
            unset wgv_key_info
        fi

        if [ -n "$wg_pre_shared_key" ]; then
            wgpsk_key_info='*********'
        else
            unset wgpsk_key_info
        fi
        comp_box "\033[31m$GW_WARN\033[0m$GW_WG_WARN"
        btm_box "1) \033[32m$GW_WG_TOGGLE\033[0m  \033[32m$wg_service\033[0m" \
            "" \
            "2) $GW_WG_SET_ENDPOINT  \033[36m$wg_server\033[0m" \
            "3) $GW_WG_SET_ENDPOINT_PORT  \033[36m$wg_port\033[0m" \
            "4) $GW_WG_SET_PUBLIC  \033[36m$wgp_key_info\033[0m" \
            "5) $GW_WG_SET_PRESHARED  \033[36m$wgpsk_key_info\033[0m" \
            "" \
            "6) $GW_WG_SET_PRIVATE  \033[33m$wgv_key_info\033[0m" \
            "7) $GW_WG_SET_IPV4  \033[33m$wg_ipv4\033[0m" \
            "8) $GW_WG_SET_IPV6  \033[33m$wg_ipv6\033[0m" \
            "" \
            "0) $COMMON_BACK"
        read -r -p "$COMMON_INPUT> " num
        case "$num" in
        "" | 0)
            break
            ;;
        1)
            if [ -n "$wg_server" ] && [ -n "$wg_port" ] && [ -n "$wg_public_key" ] && [ -n "$wg_pre_shared_key" ] && [ -n "$wg_private_key" ] && [ -n "$wg_ipv4" ]; then
                [ "$wg_service" = ON ] && wg_service=OFF || wg_service=ON
                setconfig wg_service "$wg_service"
            else
                msg_alert "\033[31m$GW_FILL_REQUIRED\033[0m"
            fi
            ;;
        [1-8])
            line_break
            read -r -p "$GW_INPUT_TEXT_DEL0> " text
            [ "$text" = 0 ] && text=''
            case "$num" in
            2)
                wg_server="$text"
                setconfig wg_server "$text" "$GT_CFG_PATH"
                ;;
            3)
                wg_port="$text"
                setconfig wg_port "$text" "$GT_CFG_PATH"
                ;;
            4)
                wg_public_key="$text"
                setconfig wg_public_key "$text" "$GT_CFG_PATH"
                ;;
            5)
                wg_pre_shared_key="$text"
                setconfig wg_pre_shared_key "$text" "$GT_CFG_PATH"
                ;;
            6)
                wg_private_key="$text"
                setconfig wg_private_key "$text" "$GT_CFG_PATH"
                ;;
            7)
                wg_ipv4="$text"
                setconfig wg_ipv4 "$text" "$GT_CFG_PATH"
                ;;
            8)
                wg_ipv6="$text"
                setconfig wg_ipv6 "$text" "$GT_CFG_PATH"
                ;;
            esac
            ;;
        *)
            errornum
            ;;
        esac
    done
}
